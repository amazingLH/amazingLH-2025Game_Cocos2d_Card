#include "GameView.h"
#include "GameModel.h"
#include "cocos2d.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace ui;

// �����������ڿ��������в��ҿ�������
int GameView::findCardIndex(const std::vector<CardView*>& cards, CardView* card) const {
	auto it = std::find(cards.begin(), cards.end(), card);
	if (it != cards.end()) {
		return std::distance(cards.begin(), it);
	}
	return -1;
}

GameView* GameView::create() {
	GameView* view = new (std::nothrow) GameView();
	if (view && view->init()) {
		view->autorelease();
		return view;
	}
	delete view;
	return nullptr;
}

bool GameView::init() {
	if (!Layer::init()) {
		return false;
	}

	visibleSize = Director::getInstance()->getVisibleSize();
	origin = Director::getInstance()->getVisibleOrigin();

	// ���ر���ͼƬ
	std::string backgroundPath = "C:\\Users\\lenovo\\Desktop\\res\\background.png";
	auto background = Sprite::create(backgroundPath);
	if (background) {
		background->setPosition(origin.x + visibleSize.width / 2, origin.y + visibleSize.height / 2);
		background->setScale(visibleSize.width / background->getContentSize().width,
			visibleSize.height / background->getContentSize().height);
		this->addChild(background, -1);
	}
	else {
		CCLOG("Failed to load background texture: %s", backgroundPath.c_str());
	}

	// ���ؿ���
	GameModel gameModel;
	std::vector<CardModel> cards = gameModel.generateRandomCards();
	setupCards(cards);

	// ����"back"��ť
	auto backLabel = Label::createWithTTF("back", "fonts/Marker Felt.ttf", 40);
	backLabel->setTextColor(Color4B::BLACK);

	// ���ð�ťλ��
	if (!bottomCards.empty()) {
		auto lastBottomCard = bottomCards.back();
		float cardRightEdge = lastBottomCard->getPositionX() +
			lastBottomCard->getContentSize().width / 2 * lastBottomCard->getScale();
		float cardCenterY = lastBottomCard->getPositionY();
		float buttonX = cardRightEdge + 200;
		float buttonY = cardCenterY;
		backLabel->setPosition(Vec2(buttonX, buttonY));
	}
	else {
		float buttonX = origin.x + visibleSize.width - 50;
		float buttonY = origin.y + visibleSize.height / 2;
		backLabel->setPosition(Vec2(buttonX, buttonY));
	}

	// ���ӵ���¼�������
	auto listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = [this, backLabel](Touch* touch, Event* event) {
		Vec2 touchLocation = touch->getLocation();
		if (backLabel->getBoundingBox().containsPoint(touchLocation)) {
			undoOperation();
			return true;
		}
		return this->onCardClicked(touch, event);
	};

	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
	this->addChild(backLabel);

	return true;
}

void GameView::setupCards(const std::vector<CardModel>& cards) {
	int cardIndex = 0;
	float halfWidth = visibleSize.width / 2;
	float halfHeight = visibleSize.height / 2;
	float centerX = origin.x + halfWidth;
	float centerY = origin.y + halfHeight;

	// �ϰ벿����ߵĿ���
	int upperLeftCount = 3;
	float upperLeftStartX = origin.x + halfWidth / 4;
	float upperLeftStartY = origin.y + visibleSize.height - halfHeight / 4;
	for (int i = 0; i < upperLeftCount; ++i) {
		CardView* cardView = CardView::create(cards[cardIndex++]);
		if (cardView) {
			float dx = (centerX - upperLeftStartX) * (i + 1) / (upperLeftCount + 1);
			float dy = (centerY - upperLeftStartY) * (i + 1) / (upperLeftCount + 1);
			float x = upperLeftStartX + dx;
			float y = upperLeftStartY + dy;
			cardView->setPosition(x, y);
			this->addChild(cardView);
			upperLeftCards.push_back(cardView);
		}
	}

	// �ϰ벿���ұߵĿ���
	int upperRightCount = 3;
	float upperRightStartX = origin.x + halfWidth + halfWidth * 3 / 4;
	float upperRightStartY = origin.y + visibleSize.height - halfHeight / 4;
	for (int i = 0; i < upperRightCount; ++i) {
		CardView* cardView = CardView::create(cards[cardIndex++]);
		if (cardView) {
			float dx = (centerX - upperRightStartX) * (i + 1) / (upperRightCount + 1);
			float dy = (centerY - upperRightStartY) * (i + 1) / (upperRightCount + 1);
			float x = upperRightStartX + dx;
			float y = upperRightStartY + dy;
			cardView->setPosition(x, y);
			this->addChild(cardView);
			upperRightCards.push_back(cardView);
		}
	}

	// ����
	int bottomCount = 3;
	float bottomX = origin.x + halfWidth;
	float bottomY = origin.y + halfHeight / 2;
	float bottomSpacing = 120;
	for (int i = 0; i < bottomCount; ++i) {
		CardView* cardView = CardView::create(cards[cardIndex++]);
		if (cardView) {
			cardView->setPosition(bottomX - (bottomCount - 1) * bottomSpacing / 2 + i * bottomSpacing, bottomY);
			this->addChild(cardView);
			bottomCards.push_back(cardView);
			cardView->setLocalZOrder(i); // ����zOrder
		}
	}
}

void GameView::removeCardView(CardView* cardView) {
	if (cardView && cardView->getParent()) {
		cardView->getParent()->removeChild(cardView, false);
	}
}

bool GameView::onCardClicked(cocos2d::Touch* touch, cocos2d::Event* event) {
	Vec2 touchLocation = touch->getLocation();
	Operation operation;

	// ����ϰ벿����ߵĿ���
	for (auto it = upperLeftCards.begin(); it != upperLeftCards.end(); ++it) {
		CardView* cardView = *it;
		if (cardView && cardView->getBoundingBox().containsPoint(touchLocation)) {
			if (bottomCards.empty()) continue;

			CardView* bottomRightCard = bottomCards.back();
			if (!bottomRightCard) continue;

			CardFaceType mainCardFace = cardView->cardModel.getCardFace();
			CardFaceType bottomCardFace = bottomRightCard->cardModel.getCardFace();

			int mainCardValue = static_cast<int>(mainCardFace);
			int bottomCardValue = static_cast<int>(bottomCardFace);

			if (mainCardValue == bottomCardValue ||
				mainCardValue == bottomCardValue + 1 ||
				mainCardValue == bottomCardValue - 1) {

				// ��¼����
				operation.type = Operation::Type::MAIN_CARD_MOVE;
				operation.mainMoveData.fromLocation = CardLocation::UPPER_LEFT;
				operation.mainMoveData.mainCardIndex = findCardIndex(upperLeftCards, cardView);
				operation.mainMoveData.originalPos = cardView->getPosition();
				operation.mainMoveData.cardModel = cardView->cardModel;
				operation.mainMoveData.bottomCardIndex = bottomCards.size() - 1;
				operation.mainMoveData.bottomCardModel = bottomRightCard->cardModel;

				// ִ���ƶ�
				Vec2 bottomCardPosition = bottomRightCard->getPosition();
				int zOrder = bottomRightCard->getLocalZOrder();

				removeCardView(bottomRightCard);
				bottomCards.pop_back();

				cardView->retain();
				removeCardView(cardView);
				cardView->setPosition(bottomCardPosition);
				this->addChild(cardView, zOrder);
				bottomCards.push_back(cardView);
				cardView->release();

				upperLeftCards.erase(it);
				operationHistory.push_back(operation);
				return true;
			}
		}
	}

	// ����ϰ벿���ұߵĿ���
	for (auto it = upperRightCards.begin(); it != upperRightCards.end(); ++it) {
		CardView* cardView = *it;
		if (cardView && cardView->getBoundingBox().containsPoint(touchLocation)) {
			if (bottomCards.empty()) continue;

			CardView* bottomRightCard = bottomCards.back();
			if (!bottomRightCard) continue;

			CardFaceType mainCardFace = cardView->cardModel.getCardFace();
			CardFaceType bottomCardFace = bottomRightCard->cardModel.getCardFace();

			int mainCardValue = static_cast<int>(mainCardFace);
			int bottomCardValue = static_cast<int>(bottomCardFace);

			if (mainCardValue == bottomCardValue ||
				mainCardValue == bottomCardValue + 1 ||
				mainCardValue == bottomCardValue - 1) {

				// ��¼����
				operation.type = Operation::Type::MAIN_CARD_MOVE;
				operation.mainMoveData.fromLocation = CardLocation::UPPER_RIGHT;
				operation.mainMoveData.mainCardIndex = findCardIndex(upperRightCards, cardView);
				operation.mainMoveData.originalPos = cardView->getPosition();
				operation.mainMoveData.cardModel = cardView->cardModel;
				operation.mainMoveData.bottomCardIndex = bottomCards.size() - 1;
				operation.mainMoveData.bottomCardModel = bottomRightCard->cardModel;

				// ִ���ƶ�
				Vec2 bottomCardPosition = bottomRightCard->getPosition();
				int zOrder = bottomRightCard->getLocalZOrder();

				removeCardView(bottomRightCard);
				bottomCards.pop_back();

				cardView->retain();
				removeCardView(cardView);
				cardView->setPosition(bottomCardPosition);
				this->addChild(cardView, zOrder);
				bottomCards.push_back(cardView);
				cardView->release();

				upperRightCards.erase(it);
				operationHistory.push_back(operation);
				return true;
			}
		}
	}

	// �����ƽ���
	for (size_t i = 0; i < bottomCards.size(); ++i) {
		CardView* cardView = bottomCards[i];
		if (cardView && cardView->getBoundingBox().containsPoint(touchLocation)) {
			if (bottomCards.size() > 1 && i != bottomCards.size() - 1) {
				// ��¼����
				operation.type = Operation::Type::BOTTOM_CARDS_SWAP;
				operation.bottomSwapData.firstIndex = i;
				operation.bottomSwapData.secondIndex = bottomCards.size() - 1;

				// ִ�н���
				CardView* lastCard = bottomCards.back();
				Vec2 clickCardPos = cardView->getPosition();
				Vec2 lastCardPos = lastCard->getPosition();

				cardView->setPosition(lastCardPos);
				lastCard->setPosition(clickCardPos);

				std::swap(bottomCards[i], bottomCards.back());

				// ����zOrder
				for (size_t j = 0; j < bottomCards.size(); ++j) {
					bottomCards[j]->setLocalZOrder(j);
				}

				operationHistory.push_back(operation);
				return true;
			}
		}
	}

	return false;
}

void GameView::undoOperation() {
	if (operationHistory.empty()) return;

	Operation operation = operationHistory.back();
	operationHistory.pop_back();

	switch (operation.type) {
	case Operation::Type::BOTTOM_CARDS_SWAP: {
		// ��������
		size_t firstIdx = operation.bottomSwapData.firstIndex;
		size_t secondIdx = operation.bottomSwapData.secondIndex;

		if (firstIdx < bottomCards.size() && secondIdx < bottomCards.size()) {
			CardView* firstCard = bottomCards[firstIdx];
			CardView* secondCard = bottomCards[secondIdx];

			Vec2 firstPos = firstCard->getPosition();
			firstCard->setPosition(secondCard->getPosition());
			secondCard->setPosition(firstPos);

			std::swap(bottomCards[firstIdx], bottomCards[secondIdx]);

			// ����zOrder
			for (size_t i = 0; i < bottomCards.size(); ++i) {
				bottomCards[i]->setLocalZOrder(i);
			}
		}
		break;
	}
	case Operation::Type::MAIN_CARD_MOVE: {
		// ��ȡ�ƶ�������
		int mainCardIndex = operation.mainMoveData.mainCardIndex;
		CardLocation fromLocation = operation.mainMoveData.fromLocation;

		// ��ȡ����
		int bottomCardIndex = operation.mainMoveData.bottomCardIndex;
		if (bottomCardIndex < bottomCards.size()) {
			CardView* movedCard = bottomCards[bottomCardIndex];

			// �����µĵ���
			CardView* newBottomCard = CardView::create(operation.mainMoveData.bottomCardModel);
			newBottomCard->setPosition(movedCard->getPosition());
			newBottomCard->setLocalZOrder(operation.mainMoveData.bottomCardIndex);
			this->addChild(newBottomCard);

			// �滻����
			bottomCards[bottomCardIndex] = newBottomCard;

			// �����ƷŻ�ԭ��
			movedCard->retain();
			removeCardView(movedCard);
			movedCard->setPosition(operation.mainMoveData.originalPos);
			this->addChild(movedCard);

			// �Ż�ԭ��������
			if (fromLocation == CardLocation::UPPER_LEFT) {
				if (mainCardIndex <= upperLeftCards.size()) {
					upperLeftCards.insert(upperLeftCards.begin() + mainCardIndex, movedCard);
				}
			}
			else {
				if (mainCardIndex <= upperRightCards.size()) {
					upperRightCards.insert(upperRightCards.begin() + mainCardIndex, movedCard);
				}
			}

			movedCard->release();
		}
		break;
	}
	}
}