#include "CardModel.h"
CardModel::CardModel() : cardFace(CardFaceType::TWO)
{
}


CardModel::CardModel(CardFaceType face) : cardFace(face)
{
}

CardFaceType CardModel::getCardFace() const
{
	return cardFace;
}